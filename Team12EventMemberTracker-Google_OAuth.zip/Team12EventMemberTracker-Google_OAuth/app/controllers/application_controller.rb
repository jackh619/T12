class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception

  CLIENT_ID = '############.apps.googleusercontent.com'
  CLIENT_SECRET = 'your-secret-goes-here'
end
