class AdminController < ApplicationController
  def team_roster
  end

  def calendar
  end

  def commitment
  end

  def event
  end
end
