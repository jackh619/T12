Rails.application.configure do
  config.google_sign_in.root = ""
end
